#!/bin/sh


stop_cloudac()
{
    for i in `seq 3`
    do ac_pid=`ps -ef | grep "cloudAC" | grep -v tail | grep -v grep | awk '{print $2}' | xargs`
    	echo "acpid is $ac_pid"
    
    	if [ "$ac_pid" != "" ]
    	then
    		kill -9 $ac_pid
    		sleep 3
    	else
    		echo "cloudAC was Stopped!!"
    		break
    	fi 
    done

    ac_pid=`ps -ef | grep "cloudAC" | grep -v tail | grep -v grep | awk '{print $2}' | xargs`
    echo "acpid is $ac_pid"
    
    if [ "$ac_pid" != "" ]
    then
    	echo "cloudAC can't Stop!! Please reboot the computer!!"
    else
    	echo "cloudAC was stopped...please wait about 5 seconds."
    	sleep 5
    	echo "cloudAC Server Stop OK."
    fi
}

stop_fdp()
{
    for i in `seq 3`
    do
    	fdp_pid=`ps -ef | grep "fdp" | grep -v tail | grep -v grep | awk '{print $2}' | xargs`
    	echo "fdp pid is $fdp_pid"
    
    	if [ "$fdp_pid" != "" ]
    	then
    		kill -9 $fdp_pid
    		sleep 3
    	else
    		echo "fdp was Stopped!!"
    		break
    	fi 
    done

    fdp_pid=`ps -ef | grep "fpd" | grep -v tail | grep -v grep | awk '{print $2}' | xargs`
    echo "fdp pid is $fdp_pid"
    
    if [ "$fdp_pid" != "" ]
    then
    	echo "fdp can't Stop!! Please reboot the computer!!"
    else
    	echo "fdp was stopped...please wait about 5 seconds."
    	sleep 5
    	echo "fdp Server Stop OK."
    fi
}
    
stop_crontab()
{
    crontab -l | grep -v zy_ac.sh | grep -v ac.sh | grep -v backup_ac_auto.sh > /usr/local/hmwifi/acrun/crontab_run.txt 
    crontab /usr/local/hmwifi/acrun/crontab_run.txt
}

stop_cloudac
stop_fdp
stop_crontab
