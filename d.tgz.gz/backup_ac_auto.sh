#!/bin/sh

ctime=`date "+%Y-%m-%d_%H_%M_%S"`

back_dir=/usr/local/hmwifi/backup/ac
mkdir -p $back_dir

back_file=$back_dir/startup.cfg.$ctime

if [ -d "/usr/local/hmwifi/acrun/" ]; then
	cp -rp /usr/local/hmwifi/acrun/startup.cfg $back_file
	rm /usr/local/hmwifi/acrun/startup.cfg.bak
	cp -rp /usr/local/hmwifi/acrun/startup.cfg /usr/local/hmwifi/acrun/startup.cfg.bak
	echo "*************$ctime AC config backup finish! *************"
fi

exit 0

