#!/bin/sh

DIR="/usr/local/hmwifi/acrun/"
if [ ! -d "$DIR" ]; then
echo "please use zy_installac.sh."
exit
fi


cd /usr/local/hmwifi/acrun

start_fdp()
{
    fdp_pid=`ps -ef | grep "fdp" | grep -v tail | grep -v grep | awk '{print $2}' | xargs`
    
    echo "fdp pid is $fdp_pid"
    if [ "$fdp_pid" != "" ];then
    echo "fdp is Started...please use zy_stopac.sh first."
    exit
    fi 
    
    for file_a in /usr/local/hmwifi/acrun/*
    do
    	temp_file=$file_a
        if [ `echo $temp_file | grep -e fdp` ];then
        	echo "fdp is Starting...$temp_file"
        	$temp_file -l 0-8 &
        fi
    done  
    
    echo "fdp is Starting...please wait about 10 seconds."
    sleep 10
    echo "fdp Server Start OK."
}

start_cloudac()
{
    ac_pid=`ps -ef | grep "cloudAC" | grep -v tail | grep -v grep | awk '{print $2}' | xargs`
    echo "acpid is $ac_pid"
    if [ "$ac_pid" != "" ];then
    echo "cloudAC is Started...please use stopac.sh first."
    exit
    fi 
    
    for file_a in /usr/local/hmwifi/acrun/*
    do
    	temp_file=$file_a        
        if [ `echo $temp_file | grep -e cloudAC` ];then
        	echo "cloudAC is Starting...$temp_file"
        	$temp_file &
        fi
    done  
    
    echo "cloudAC is Starting...please wait about 10 seconds."
    sleep 10
    echo "cloudAC Server Start OK."
}

start_crontab()
{
    crontab -l | grep -v ac.sh | grep -v backup_ac_auto.sh > /usr/local/hmwifi/acrun/crontab_run.txt
    echo "*/1 * * * * /usr/local/hmwifi/acrun/zy_ac.sh" > /usr/local/hmwifi/acrun/crontab_run.txt
    echo "0 1 * * * /usr/local/hmwifi/acrun/backup_ac_auto.sh >> /usr/local/hmwifi/acrun/backup_ac_auto.log" >> /usr/local/hmwifi/acrun/crontab_run.txt

    crontab -u root /usr/local/hmwifi/acrun/crontab_run.txt 
}

start_fdp
start_cloudac
start_crontab
