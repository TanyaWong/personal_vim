#!/bin/sh -e
#
# dpdk_init.sh
# This script in order to setting dpdk environment, include mount hugepage,
# insmode kernel interface ko , listen physical interface for dpdk.
# and You can find be called by rc.local

ifname=eth3

mkdir -p /mnt/huge 
mount -t hugetlbfs nodev /mnt/huge 

modprobe uio                               
insmod /usr/local/hmwifi/acrun/igb_uio.ko
insmod /usr/local/hmwifi/acrun/rte_kni.ko

ifname_up=`ifconfig | grep "$ifname" | grep -v grep | grep -v tail | xargs`
if [ "$ifname_up" != "" ]
then
    ifconfig down $ifname
fi
/usr/bin/python3 /usr/local/hmwifi/acrun/dpdk-devbind.py --bind=igb_uio $ifname 
