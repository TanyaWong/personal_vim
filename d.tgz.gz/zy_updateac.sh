#!/bin/sh

process_pid()
{
    ac_pid=`ps -ef | grep "cloudAC" | grep -v tail | grep -v grep | awk '{print $2}' | xargs`
    fdp_pid=`ps -ef | grep "fdp" | grep -v tail | grep -v grep | awk '{print $2}' | xargs`

    if [ "$ac_pid" != "" -o "$fdp_pid" != "" ];then
        return 1
    fi

    return 0
}

main_thread()
{
    for i in `seq 3`
    do
        process_pid
        if [ $? -eq 1 ]
        then
            ./zy_stopac.sh
            sleep 10
        else
            break
        fi
    done

    process_pid
    if [ $? -eq 1 ]
    then
        echo "can't kill process, please check..."
        return -1
    fi

    DIR="/usr/local/hmwifi/acrun/"
    if [ ! -d "$DIR" ]; then
    echo "please use zy_installac.sh."
    exit
    fi
        
    DIR="/usr/local/hmwifi/acrun"
    if [ -d "$DIR" ]; then
    rm -f $DIR/cloudAC_*
    rm -f $DIR/*.bin
    rm -f $DIR/startac.sh
    rm -f $DIR/stopac.sh
    rm -f $DIR/backup_ac_auto.sh
    rm -f $DIR/ac_crontab.txt
    rm -f $DIR/aclog.txt
    rm -f $DIR/aclog.txt?
    rm -f $DIR/fdp
    rm -f $DIR/cw_*
    rm -f $DIR/*.ko
    rm -f $DIR/dpdk-devbind.py
    rm -f $DIR/dpdk-init.sh
    rm -f $DIR/ac.sh
    rm -f $DIR/zy_*.sh
    
    cp *.bin $DIR
    cp backup_ac_auto.sh $DIR/backup_ac_auto.sh
    cp cloudAC_* $DIR
    cp AppleOUI.txt $DIR
    
    #新增数据面文件
    cp fdp $DIR
    cp cw_cmd $DIR
    cp *.ko $DIR
    cp dpdk-devbind.py $DIR
    cp dpdk_init.sh $DIR
    cp zy_ac.sh $DIR
    cp zy_startac.sh $DIR
    cp zy_stopac.sh $DIR
    #end
    
    chmod 777 $DIR/cloudAC_*
    chmod 777 $DIR/fdp
    ./zy_startac.sh
    fi
}

trap "" 1
main_thread &
trap 1
