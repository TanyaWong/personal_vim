#!/bin/sh

str1="/usr/local/hmwifi/acrun/dpdk_init.sh"
str2="/usr/local/hmwifi/acrun/zy_startac.sh"
str3="GRUB_CMDLINE_LINUX=\"default_hugepagesz=1G hugepagesz=2M hugepages=512 isolcpus=0-2\""

DIR="/usr/local/hmwifi/acrun/"
if [ ! -d "$DIR" ]; then
mkdir -p $DIR
fi

copy_file()
{
    echo "start copy file ..."
    rm -rf $DIR/cloudAC_*
    rm -rf $DIR/fdp
    
    cp cloudAC_* $DIR
    cp backup_ac_auto.sh $DIR
    cp *.bin $DIR
    cp AppleOUI.txt $DIR

    cp fdp $DIR
    cp cw_cmd $DIR
    cp *.ko $DIR 
    cp dpdk-devbind.py $DIR
    cp dpdk_init.sh $DIR
    cp config.ini $DIR
    cp zy_ac.sh $DIR
    cp zy_startac.sh $DIR
    cp zy_stopac.sh $DIR

    chmod 777 $DIR/dpdk_init.sh
    chmod 777 $DIR/dpdk-devbind.py
    chmod 777 $DIR/fdp
    chmod 777 $DIR/cloudAC_*
}

change_env()
{
    echo "start change environment ..."
    sleep 1
    rc_str=`cat /etc/rc.local | grep "$str1"`
    if [ "X$rc_str" = "X" ]; then
        sed -i "s|^exit 0|$str1\n$str2\n&|g" /etc/rc.local
    fi
        
    #update grub, last step need reboot system
    sed -i "s|^GRUB_CMDLINE_LINUX=.*|$str3|g" /etc/default/grub
    grub-mkconfig -o /boot/grub/grub.cfg

    echo "ac set coredump!"
    echo "ulimit -c unlimited " >> /etc/profile
    echo "ulimit -n 65535 " >> /etc/profile
    echo "ac set coredump finish!"
}

reboot_system()
{
    echo "ac install finish! and will reboot computer!!!"
    read -p "Do you want to reboot [Y/N]?" answer
    case $answer in
    Y|y) echo "fine ,reboot" 
    reboot;;
    N|n) echo "ok,please reboot later";;
    *) echo "error choice";;
    esac
}

copy_file
change_env
reboot_system
