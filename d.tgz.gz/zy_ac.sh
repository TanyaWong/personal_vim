#!/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin

cd /usr/local/hmwifi/acrun

start_cloudAC()
{
    echo "start cloudAC ..."
    for file_a in /usr/local/hmwifi/acrun/*
    do
    	temp_file=$file_a        
        if [ `echo $temp_file | grep -e cloudAC` ];then
        	echo "cloudAC is Starting...$temp_file"
        	$temp_file &
        fi
    done  
}

start_fdp()
{
    echo "start fdp ..."
    for file_a in /usr/local/hmwifi/acrun/*
    do
    	temp_file=$file_a        
        if [ `echo $temp_file | grep -e fdp` ];then
        	echo "cloudAC is Starting...$temp_file"
        	$temp_file -l 0-8 &
        fi
    done  
}

stop_fdp()
{
    echo "stop fdp ..."
    for i in `seq 3`
    do
    	fdp_pid=`ps -ef | grep -v "zy_fdp"| grep "fdp" | grep -v tail | grep -v grep | awk '{print $2}' | xargs`
    	echo "fdp pid is $fdp_pid"
    
    	if [ "$fdp_pid" != "" ]
    	then
    		kill -9 $fdp_pid
    		sleep 3
    	else
    		echo "fdp was Stopped!!"
    		break
    	fi 
    done
}

fdp_pid=`ps -ef | grep "fdp" | grep -v "zy_fdp.sh" | grep -v tail | grep -v grep | awk '{print $2}' | xargs`
ac_pid=`ps -ef | grep "cloudAC_" | grep -v tail | grep -v grep | awk '{print $2}' | xargs`


if [ "$ac_pid" != "" ];then 
echo "************* AC is still running! *************"

else
    stop_fdp
    start_fdp
    start_cloudAC
fi

sleep 1
fdp_pid=`ps -ef | grep "fdp" | grep -v tail | grep -v grep | awk '{print $2}' | xargs`

if [ "$fdp_pid" != "" ];then 
echo "************* fdp is still running! *************"

else
    start_fdp
fi

